/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package cine;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 *
 * @author PRACTICA
 */
import javax.swing.JPanel;
public class Sala1 extends javax.swing.JFrame {
    private ArrayList<Integer> numerospersonas = new ArrayList<>();
    private ArrayList<String> NombresPeliculas = new ArrayList<>();
    private HashMap<String, Integer> peliculasPersonas = new HashMap<>();
    private HashMap<String, String> nombresPeliculas = new HashMap<>();
    
    /**
     * Creates new form NewJFrame1
     */
    
    public Sala1() {
        asignarNombrePelicula();
        inicializarPeliculas();
        initComponents();
        
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel2, "src/imagenes/kfp.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel3, "src/imagenes/duna.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel4, "src/imagenes/madame.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel5, "src/imagenes/Anatomia.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel12, "src/imagenes/Aquaman.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel7, "src/imagenes/Bob.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel8, "src/imagenes/Ferrari.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel9, "src/imagenes/Imaginary.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel10, "src/imagenes/Robot.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel11, "src/imagenes/elniño.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel6, "src/imagenes/Demon.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel13, "src/imagenes/ex.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel14, "src/imagenes/ghost.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel16, "src/imagenes/Hombre.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel15, "src/imagenes/Free.jpg");
      
        
    }
    private void inicializarPeliculas() {
        // Agregar nombres de películas y cantidades de personas
        NombresPeliculas.add("kfp.jpg"); 
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("duna.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("madame.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Anatomia.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Aquaman.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Bob.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Ferrari.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Imaginary.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Robot.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("elniño.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Demon.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("ex.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("ghost.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Hombre.png");
        numerospersonas.add(generarNumeroAleatorio());
        NombresPeliculas.add("Free.jpg");
        numerospersonas.add(generarNumeroAleatorio());
        for(int i=0;i<NombresPeliculas.size();i++ ){
            peliculasPersonas.put(NombresPeliculas.get(i),numerospersonas.get(i));
        }

    }

private void asignarNombrePelicula() {
    nombresPeliculas.put("Kung fu Panda 4", "kfp.jpg");
    nombresPeliculas.put("Duna 2", "duna.jpg");
    nombresPeliculas.put("Madame Web", "Madame.jpg");
    nombresPeliculas.put("Anatomia de una Caida", "Anatomia.jpg");
    nombresPeliculas.put("Aquaman 2:El Reino Perdido", "Aquaman.jpg");
    nombresPeliculas.put("Bob Marley", "Bob.jpg");
    nombresPeliculas.put("Ferrari", "Ferrari.jpg");
    nombresPeliculas.put("Imaginary", "Imaginary.jpg");
    nombresPeliculas.put("Robot Dreams", "Robot.jpg");
    nombresPeliculas.put("El Niño y la Garza", "elniño.jpg");
    nombresPeliculas.put("Demon Slayer", "Demon.jpg");
    nombresPeliculas.put("Exorcistas", "ex.jpg");
    nombresPeliculas.put("El Fantasma de Canterville", "ghost.jpg");
    nombresPeliculas.put("El Hombre de los Sueños", "Hombre.png");
    nombresPeliculas.put("Freelance", "Free.jpg");
    

}
 
public static void swapKeysAndValues(Map<String, String> nombresPeliculas, Map<String, Integer> numerospersonas) {
      // Crear un nuevo mapa temporal para almacenar los nuevos valores de nombresPeliculas y numerospersonas
        Map<String, Integer> newNumerospersonas = new HashMap<>();

        // Iterar sobre las entradas del mapa nombresPeliculas
        for (Map.Entry<String, String> entry : nombresPeliculas.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            // Verificar si el mapa numerospersonas contiene el valor actual de nombresPeliculas
            if (numerospersonas.containsKey(value)) {
                // Obtener el valor correspondiente en numerospersonas
                int oldValue = numerospersonas.get(value);

                // Colocar la clave y el valor intercambiados en los nuevos mapas
                newNumerospersonas.put(key, oldValue);
            }
        }

        // Limpiar los mapas originales
        nombresPeliculas.clear();
        numerospersonas.clear();

        // Iterar sobre las entradas del nuevo mapa numerospersonas y colocarlas en los mapas originales
        for (Map.Entry<String, Integer> entry : newNumerospersonas.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            nombresPeliculas.put(value.toString(), key);
            numerospersonas.put(key, value);
        }
    }

private String peliculamasPopular(){
 String peliculamasPopular= "";
 int maxPersonas = Integer.MIN_VALUE;

for(String Pelicula:peliculasPersonas.keySet()){
    int personas = peliculasPersonas.get(Pelicula);
    if(personas > maxPersonas){
        maxPersonas = personas;
        peliculamasPopular = Pelicula;
    
    }
}
return peliculamasPopular;
}
     /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jScrollBar1 = new javax.swing.JScrollBar();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(java.awt.Color.black);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setText("jButton2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 140, -1, -1));
        jPanel2.add(jScrollBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1213, 0, -1, 900));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Peliculas Excibidas En Esta Sala ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 20, 528, 55));

        jLabel2.setText("jLabel2");
        jLabel2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jLabel2MouseMoved(evt);
            }
        });
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 190, 182, 199));

        jLabel3.setText("jLabel3");
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(248, 190, 182, 199));

        jLabel4.setText("jLabel4");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 190, 182, 199));

        jLabel5.setText("jLabel5");
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel5MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(732, 190, 182, 199));

        jLabel6.setText("jLabel7");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 420, 182, 199));

        jLabel7.setText("jLabel8");
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(248, 420, 182, 199));

        jLabel8.setText("jLabel9");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 420, 182, 199));

        jLabel10.setText("jLabel11");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(974, 420, 182, 199));

        jLabel9.setText("jLabel10");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(732, 420, 182, 199));

        jLabel11.setText("jLabel12");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 643, 182, 199));

        jLabel12.setText("jLabel13");
        jLabel12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel12MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(248, 643, 182, 199));

        jLabel13.setText("jLabel14");
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 643, 182, 199));

        jLabel14.setText("jLabel15");
        jLabel14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel14MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(732, 643, 182, 199));

        jLabel15.setText("jLabel17");
        jLabel15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel15MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(974, 190, 182, 199));

        jLabel16.setText("jLabel16");
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(974, 643, 182, 199));

        jButton1.setText("Volver");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 140, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1220, 900));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel2MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel2MouseMoved

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked

        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("kfp.jpg") );
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("duna.jpg") );
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("madame.jpg") );
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseClicked
        
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Anatomia.jpg") );

    }//GEN-LAST:event_jLabel5MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Aquaman.jpg"));
    }//GEN-LAST:event_jLabel6MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Bob.jpg")  );
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Ferrari.jpg") );
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Imaginary.jpg")  );
    }//GEN-LAST:event_jLabel9MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Robot.jpg"));
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("elniño.jpg")  );
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel12MouseClicked
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Demon.jpg"));
    }//GEN-LAST:event_jLabel12MouseClicked

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("ex.jpg")  );
    }//GEN-LAST:event_jLabel13MouseClicked

    private void jLabel14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel14MouseClicked
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("ghost.jpg")  );
    }//GEN-LAST:event_jLabel14MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Hombre.png"));
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jLabel15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel15MouseClicked
        JOptionPane.showMessageDialog(null,"el numero de personas que entro a ver esta pelicula es " + peliculasPersonas.get("Free.jpg")  );
    }//GEN-LAST:event_jLabel15MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        JOptionPane.showMessageDialog(null, "Es la Pelicula Mas Vista " + peliculamasPopular() + " con esta cantidad de personas " + peliculasPersonas.get(peliculamasPopular())  );
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        NewJFrame n = new NewJFrame();
        n.setDefaultCloseOperation(Sala1.EXIT_ON_CLOSE);
        n.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sala1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sala1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sala1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sala1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Sala1().setVisible(true);
            }
        });
    


    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollBar jScrollBar1;
    // End of variables declaration//GEN-END:variables

private int generarNumeroAleatorio() {
        return (int) (Math.random() *80 ) + 150 ; // Genera un número aleatorio entre 0 y 99
    }



}
